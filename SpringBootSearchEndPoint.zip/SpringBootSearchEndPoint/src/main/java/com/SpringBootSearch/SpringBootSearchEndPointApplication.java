package com.SpringBootSearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSearchEndPointApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSearchEndPointApplication.class, args);
	}

}
