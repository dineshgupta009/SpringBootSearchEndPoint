package com.NSEOptionChaing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NseOptionChaingApplication {

	public static void main(String[] args) {
		SpringApplication.run(NseOptionChaingApplication.class, args);
	}

}
