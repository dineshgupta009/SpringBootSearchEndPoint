package com.example.TechnicalAnalysis.entity;

public class PETotal {

	double totOI;
	
	double totVol;

	public double getTotOI() {
		return totOI;
	}

	public void setTotOI(double totOI) {
		this.totOI = totOI;
	}

	public double getTotVol() {
		return totVol;
	}

	public void setTotVol(double totVol) {
		this.totVol = totVol;
	}
	
}
