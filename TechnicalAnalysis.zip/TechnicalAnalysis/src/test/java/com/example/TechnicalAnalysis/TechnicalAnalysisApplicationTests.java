package com.example.TechnicalAnalysis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechnicalAnalysisApplicationTests {

	@Test
	void contextLoads() {
	}

}
